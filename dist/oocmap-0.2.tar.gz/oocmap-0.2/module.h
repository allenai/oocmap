#ifndef OOCMAP_MODULE_H
#define OOCMAP_MODULE_H

#define PY_SSIZE_T_CLEAN
#include <Python.h>

PyMODINIT_FUNC PyInit_oocmap();

#endif